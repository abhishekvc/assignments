package com.ttl.SpringBootJPACrudExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
